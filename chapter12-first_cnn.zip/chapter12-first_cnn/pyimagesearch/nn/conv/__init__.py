# import the necessary packages
from .shallownet import ShallowNet